from ._version import __version__

# shortcut for most-used symbols
from msgpackrpc.loop import Loop
from msgpackrpc.client import Client
from msgpackrpc.server import Server
from msgpackrpc.address import Address
